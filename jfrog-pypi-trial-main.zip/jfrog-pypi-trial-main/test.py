from main import run

def test_hello_world():
    assert say_hello() == "Hello World!"
